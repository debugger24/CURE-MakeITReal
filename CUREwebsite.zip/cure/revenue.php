<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png" />
	<link rel="icon" type="image/png" href="assets/img/favicon.png" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>CURE = Curing Urban and Rural Equally</title>
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
	<meta name="viewport" content="width=device-width" />
	<?php include "lib/css.php" ?>
</head>

<body>
	<div class="wrapper">
		<div class="sidebar" data-active-color="rose" data-background-color="white" data-image="assets/img/sidebar-1.jpg">
			<div class="logo">
				<a href="#" class="simple-text logo-mini">

                </a>
				<a href="#" class="simple-text logo-normal">
                    CURE
                </a>
			</div>
			<div class="sidebar-wrapper">
				<ul class="nav">
					<li>
						<a href="dashboard.php">
                            <i class="material-icons">dashboard</i>
                            <p>Dashboard</p>
                        </a>
					</li>
					<li>
						<a href="patients.php">
                            <i class="material-icons">person</i>
                            <p>Patients</p>
                        </a>
					</li>
					<li class="active">
						<a href="revenue.php">
                            <i class="fa fa-line-chart" aria-hidden="true"></i>
                            <p>Revenue</p>
                        </a>
					</li>
					<li>
						<a href="rating.php">
                            <i class="fa fa-star-half-o" aria-hidden="true"></i>
                            <p>Rating and Feedback</p>
                        </a>
					</li>
					<li>
						<a href="map.php">
                            <i class="material-icons">location_on</i>
                            <p>Disease Map</p>
                        </a>
					</li>
				</ul>
			</div>
		</div>
		<div class="main-panel">
			<nav class="navbar navbar-transparent navbar-absolute">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
						<a class="navbar-brand" href="#"> Revenue </a>
					</div>
				</div>
			</nav>
			<div class="content">
				<div class="container-fluid">
					<div class="row">
					</div>
				</div>
			</div>
			<footer class="footer">
				<div class="container-fluid">
					<p class="copyright pull-right">
						&copy;
						<script>
							document.write(new Date().getFullYear())
						</script>
						Developed by TeamName (a.k.a HumBeerHein)</a>
					</p>
				</div>
			</footer>
		</div>
	</div>
</body>
<?php include "lib/js.php" ?>

</html>
