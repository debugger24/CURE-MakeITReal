<?php

session_start();

// $_SESSION['demo'] = "Rahul";

print_r($_SESSION);

?>