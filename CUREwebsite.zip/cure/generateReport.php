<?php

// TODO @Tarun: Accept Data in POST format and dump in Database

// TODO @Tarun: Return status {"status" : "success"} or {"status" : "fail"} in JSON

print_r($_POST);



function generateReport($appoinment_id, $symptoms, $diseases, $medicines) {
	//

	//
	//return  array("status"=>"fail") ;

	$sarr=explode(',', $symptoms);
	$darr=explode(',', $diseases);
	$marr=explode(',', $medicines);

	include("config.php");
	$conn=$db;
	if ($conn->connect_error) {
		return array("status"=>"fail") ;
		die("Connection failed: " . $conn->connect_error);
	} 

	$sql = "SELECT Age,Sex,District,State FROM Patient WHERE UID = (SELECT UID FROM Apoint WHERE AppointID = $appoinment_id)";
	$result = $conn->query($sql);
	//echo $sql;
	if ($result->num_rows == 0) {
    // output data of each row
    	echo "0 results";
    	return array("status"=>"fail") ;
	}	 
	
	//$conn->close();

	$row = $result->fetch_assoc();
	//print_r($darr);

	foreach ($darr as $dis) {

		echo $dis;
		// print_r($row);
		$a=$row['Age'];$s=$row['Sex'];$d=$row['District'];$st=$row['State'];
    	$sql = "INSERT into DATASHEET VALUES ('$dis',$a ,'$s' ,'$d' , '$st')";
    	//$sql = "";
		//echo $sql;
		$result = $conn->query($sql);

	}
	$conn->close();
	return array("status"=>"success");

	// TODO @Tarun: Return status {"status" : "success"} or {"status" : "fail"} in JSON
}











echo json_encode( generateReport($_POST['appoinment_id'], $_POST['symptoms'], $_POST['diseases'], $_POST['medicines']) );





?>
