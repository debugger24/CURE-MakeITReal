<?php
	session_destroy();
	session_start();
	
	if(isset($_POST['UID'])){
		$_SESSION['patient_uid'] = $_POST['UID'];
	}

	if(isset($_POST['1'])){
		echo "working";
	}

	/*echo($_GET['UID']);
	echo "GET\n ";
	print_r($_GET);
	echo "\n\nPOST\n";
	print_r($_POST);
	echo "\n\nSESSION\n";
	print_r($_SESSION);*/

	if(isset($_GET["reset"]))
	unset($_SESSION["patient_uid"]);
?>

<!doctype html>
<html lang="en">


<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png" />
	<link rel="icon" type="image/png" href="assets/img/favicon.png" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Curing Urban and Rural Equally</title>
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
	<meta name="viewport" content="width=device-width" />
	<?php include "lib/css.php" ?>
</head>

<body>
	<div class="wrapper">
		<div class="sidebar" data-active-color="rose" data-background-color="white" data-image="assets/img/sidebar-1.jpg">
			<div class="logo">
				<a href="#" class="simple-text logo-mini">

                </a>
				<a href="#" class="simple-text logo-normal">
                    CURE
                </a>
			</div>
			<div class="sidebar-wrapper">
				<ul class="nav">
					<li>
						<a href="dashboard.php">
                            <i class="material-icons">dashboard</i>
                            <p>Dashboard</p>
                        </a>
					</li>
					<li class="active">
						<a href="patients.php">
                            <i class="material-icons">person</i>
                            <p>Patients</p>
                        </a>
					</li>
					<li>
						<a href="revenue.php">
                            <i class="fa fa-line-chart" aria-hidden="true"></i>
                            <p>Revenue</p>
                        </a>
					</li>
					<li>
						<a href="rating.php">
                            <i class="fa fa-star-half-o" aria-hidden="true"></i>
                            <p>Rating and Feedback</p>
                        </a>
					</li>
					<li>
						<a href="map.php">
                            <i class="material-icons">location_on</i>
                            <p>Disease Map</p>
                        </a>
					</li>
					<li>
						<a href="logout.php">
                            <i class="fa fa-sign-out" aria-hidden="true"></i>
                            <p>Logout</p>
                        </a>
					</li>
				</ul>
			</div>
		</div>
		<div class="main-panel">
			<nav class="navbar navbar-transparent navbar-absolute">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
						
					</div>
				</div>
			</nav>

			<div class="col-md-12"  <?php if (isset($_SESSION['patient_uid'])  ) { echo 'style="display:none;"'; } ?>>
							<div class="card">
								<div class="card-header card-header-icon" data-background-color="red">
									<i class="fa fa-file-text fa-2x" aria-hidden="true"></i>
								</div>
								<div class="card-content">
									<h4 class="card-title">Patient Information</h4>
									<form method="post" action="patients_c.php">
										<p>Aadhaar - UID</p>
										<div class="form-group label-floating is-empty">
											<input type="text" name="UID" class="form-control">
											
										</div>
										
										<button type="submit" class="btn btn-fill btn-rose">Submit</button>
									</form>
								</div>
							</div>
						</div>
			<div class="content">
				<div class="container-fluid">
					<div class="row"  <?php if (!isset($_SESSION['patient_uid']) || isset($_POST['1'])){ echo 'style="display:none;"'; } ?>>
						
						<div class="col-md-12">
							<div class="card">
								<div class="card-header card-header-icon" data-background-color="rose">
									<i class="material-icons">assignment</i>
								</div>
								<div class="card-content">
								<form  method = "post" action="patients_c.php">
									<h4 class="card-title">Doctors</h4><p style="text-align: right;">
									<a href="patients_c.php?reset=patient" >Patient LogOut</a>
									</p>
									<div class="table-responsive">
										<table class="table">
											<thead>
												<tr>
													<th class="text-center">#</th>
													<th>Name</th>
													<th>Status</th>
													<th>Age</th>
													<th>Sex</th>
													<th>Experience</th>
													<th >Appoinment Time</th>
													<th >Actions</th>
												</tr>
											</thead>
											<tbody>

												<tr>
													<td class="text-center">1</td>
													<td>Prajwal Prabhu</td>
													<td style="color: green; font:bold;">Online</td>
													<td>21</td>
													<td>Male</td>
													<td>27</td>

													<td >10:25 AM</td>
													<td ><button name="1" value="1" class="btn btn-fill btn-rose">Book</button></td>
												</tr>
											</tbody>
										</table>
									</div>
									</form>
								</div>
							</div>
						</div>
					</div>
					<div <?php if (!isset($_POST['1'])){ echo 'style="display:none;"'; } ?> >
					
					<div class="col-md-6">
							<div class="card">
								<div class="card-header card-header-icon" data-background-color="red">
									<i class="fa fa-file-text fa-2x" aria-hidden="true"></i>
								</div>
								<div class="card-content">
									<h4 class="card-title">Appointments</h4>
									<form method="post" action="patients_c.php">
									<div class="table-responsive">
                                        <table class="table">
                                            <thead >
                                                <tr>
                                                
                                                <th>Date</th>
                                                <th>Time</th>
                                            </tr></thead>
                                            <tbody>

                                            	<?php

                                            		include("config.php");
                                            		$conn=$db;
                                            		if ($conn->connect_error) {
													die("Connection failed: " . $conn->connect_error);
													} 

													$sql = "SELECT Date,Time FROM Apoint";
													$result = $conn->query($sql);

													if ($result->num_rows > 0) {
												    // output data of each row
												    while($row = $result->fetch_assoc()) {
												        echo  "<tr><td>".$row["Date"]."</td><td >".$row["Time"]."</td></tr>"; 
												    	}
													}	 
													else {
													    echo "0 results";
													}
												$conn->close();
                                            	?>
                                                
                                            </tbody>
                                        </table>
                                    </div>
                               
                          
									</form>
								</div>
							</div>
					</div>

					<div class="col-md-6">
					<div class="card">
                                <div class="card-header card-header-icon" data-background-color="red">
									<i class="fa fa-file-text fa-2x" aria-hidden="true"></i>
								</div>
                                <div class="card-content">
                                    <h4 class="card-title">Date Picker</h4>
                                    <div class="form-group">
                                        <label class="label-control">Date Picker</label>
                                        <input type="text" class="form-control datepicker" value="10/10/2016">
                                    <span class="material-input"></span></div>
                                </div>
                                
                                <div class="card-content">
                                    <div class="form-group">
                                        <label class="label-control">Time Picker</label>
                                        <input type="text" class="form-control timepicker" value="14:00">
                                    <span class="material-input"></span></div>
                                </div>

                                <div class="card-content">
									
									<form method="#" action="#">
										<p>Symptoms</p>
										<div class="form-group label-floating is-empty">
											<input type="text" name="symptoms_input" class="form-control">
											<input type="text" class="tagsinput" name="symptoms" data-role="tagsinput" ata-color="rose" value="XYZ, ABC, PQRST" />
										</div>
										
										<button type="submit" class="btn btn-fill btn-rose">Submit</button>
									</form>
								</div>
                            </div>
                            </div>
                            
                        </div>
                        <div class="card-content col-md-6">
									<iframe width="600" height="465" src="https://www.gruveo.com/embed/?code=appoinment_<?php echo ($_GET['appoinment_id']); ?>" frameborder="0" allowfullscreen></iframe>
								</div>
					<div class="row" <?php if (!isset($_POST['1'])){ echo 'style="display:none;"'; } ?>>
						
						<div class="col-md-12">
							<div class="card">
								
								
							</div>
						</div>
					</div>
				</div>
			</div>
			<footer class="footer">
				<div class="container-fluid">
					<p class="copyright pull-right">
						&copy;
						<script>
							document.write(new Date().getFullYear())
						</script>
						Developed by TeamName (a.k.a HumBeerHein)</a>
					</p>
				</div>
			</footer>
		</div>
	</div>
</body>
<?php include "lib/js.php" ?>

</html>
