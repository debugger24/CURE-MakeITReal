<?php

session_start();
print_r($_SESSION);
include("config.php");

function getProctorStudentList( $loginID) {

	
	$con = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);

	$myquery="SELECT A.AppointID, A.UID, A.Patient, A.Age, A.Sex, P.Locality, A.Time,A.Symptoms FROM Apoint A, Patient P WHERE A.Doctor = '$loginID' AND A.UID = P.UID ";
	echo ($myquery);
	$result = mysqli_query($con, $myquery);
	$response['patient'] = array();
    if($result) {
    	echo ("NOTHI");
        if(mysqli_num_rows($result) > 0) {

            while($row = mysqli_fetch_assoc($result)) {
            	echo ($row);
                array_push($response["patient"], $row);
            }
            mysqli_close($con);
            return $response['patient'];
        }
    }
    mysqli_close($con);
    return NULL;
}




// TODO @Tarun : Check Doctor ID from SESSION['doctor)_id'] which you set during Login
if(isset($_SESSION['login_user'])){

	echo json_encode(getProctorStudentList($_SESSION['login_user']));	

}

else {
        $response["status"] = "";
        echo json_encode($response);
    }

// TODO @Tarun : Execute SQL Queries to Fetch Appoinements WHERE doctor_id is matching as that of SESSION['doctor)_id'] and return the JSON String in getAppoinments.json format

?>
