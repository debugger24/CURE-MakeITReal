<!doctype html>
<html lang="en">

<?php
	$_SESSION['doctor_ID'] = "432";
?>

<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="img/logo.jpg" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>CURE = Curing Urban and Rural Equally</title>
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
	<meta name="viewport" content="width=device-width" />
	<?php include "lib/css.php" ?>
</head>

<body>
	<div class="wrapper">
		<div class="sidebar" data-active-color="rose" data-background-color="white" data-image="assets/img/sidebar-1.jpg">
			<div class="logo">
				<a href="#" class="simple-text logo-mini">

                </a>
				<a href="#" class="simple-text logo-normal">
                    <img src="img/sidebar.jpg" width="150px"/>
                </a>
			</div>
			<div class="sidebar-wrapper">
				<ul class="nav">
					<li>
						<a href="dashboard.php">
                            <i class="material-icons">dashboard</i>
                            <p>Dashboard</p>
                        </a>
					</li>
					<li class="active">
						<a href="patients.php">
                            <i class="material-icons">person</i>
                            <p>Patients</p>
                        </a>
					</li>
					<li>
						<a href="revenue.php">
                            <i class="fa fa-line-chart" aria-hidden="true"></i>
                            <p>Revenue</p>
                        </a>
					</li>
					<li>
						<a href="rating.php">
                            <i class="fa fa-star-half-o" aria-hidden="true"></i>
                            <p>Rating and Feedback</p>
                        </a>
					</li>
					<li>
						<a href="map.php">
                            <i class="material-icons">location_on</i>
                            <p>Disease Map</p>
                        </a>
					</li>
					<li>
						<a href="logout.php">
                            <i class="fa fa-sign-out" aria-hidden="true"></i>
                            <p>Logout</p>
                        </a>
					</li>
				</ul>
			</div>
		</div>
		<div class="main-panel">
			<nav class="navbar navbar-transparent navbar-absolute">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
						<a class="navbar-brand" href="#"> Patients </a>
					</div>
				</div>
			</nav>
			<div class="content">
				<div class="container-fluid">
					<div class="row" <?php if(isset($_GET['appoinment_id'])) {echo "style='display: none;'";} ?>>
						<div class="col-md-12">
							<div class="card">
								<div class="card-header card-header-icon" data-background-color="rose">
									<i class="material-icons">assignment</i>
								</div>
								<div class="card-content">
									<h4 class="card-title">Waiting Patients</h4>
									<div class="table-responsive">
										<table class="table">
											<thead>
												<tr>
													<th class="text-center">#</th>
													<th>Name</th>
													<th>Locality</th>
													<th>Age</th>
													<th>Sex</th>
													<th>Symptoms</th>
													<th class="text-right">Appoinment Time</th>
													<th class="text-right">Actions</th>
												</tr>
											</thead>
											<tbody id="appoinmentList">

											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row" <?php if(!isset($_GET['appoinment_id'])) {echo "style='display: none;'";} ?>>
						<div class="col-lg-6 col-md-12">
							<div class="card">
								<div class="card-header card-header-text" data-background-color="red">
									<h4 class="card-title">Video Call</h4>
								</div>
								<div class="card-content">
									<iframe width="600" height="465" src="https://www.gruveo.com/embed/?code=appoinment_<?php echo ($_GET['appoinment_id']); ?>" frameborder="0" allowfullscreen></iframe>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="card">
								<div class="card-header card-header-icon" data-background-color="red">
									<i class="fa fa-file-text fa-2x" aria-hidden="true"></i>
								</div>
								<div class="card-content">
									<h4 class="card-title">Report</h4>
									<form method="post" action="proctor/addStudent.php" id="addStudentForm">
										<input type="text" style="display:none" name="appoinment_id" value="<?php echo $_GET['appoinment_id'] ?>" />
										<p>Symptoms</p>
										<div class="form-group label-floating is-empty">
											<!-- <input type="text" name="symptoms_input" class="form-control"> -->
											<input type="text" class="tagsinput" name="symptoms" data-role="tagsinput" ata-color="rose" value="XYZ, ABC, PQRST" />
										</div>
										<p>Diseases</p>
										<div class="form-group label-floating is-empty">
											<!-- <input type="text" id="diseaseText" name="diseases_input" class="form-control"> -->
											<input type="text" id="disease" class="tagsinput" name="diseases" data-role="tagsinput" ata-color="rose" value="XYZ, ABC, PQRST" />
										</div>
										<p>Medicines</p>
										<div class="form-group label-floating is-empty">
											<!-- <input type="text" name="medicines_input" class="form-control"> -->
											<input type="text" class="tagsinput" name="medicines" data-role="tagsinput" ata-color="rose" value="XYZ, ABC, PQRST" />
										</div>
										<button type="submit" class="btn btn-fill btn-rose">Submit</button>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<footer class="footer">
				<div class="container-fluid">
					<p class="copyright pull-right">
						&copy;
						<script>
							document.write(new Date().getFullYear())
						</script>
						Developed by TeamName (a.k.a HumBeerHein)</a>
					</p>
				</div>
			</footer>
		</div>
	</div>
</body>
<?php include "lib/js.php" ?>
<script src="js/doctor_patients.js"></script>

</html>
