




function getProctorStudentList($facultyID, $deptID) {
        /********************************
        {response: []}
        *********************************/
        $con = $db;
        $facultyID = mysqli_real_escape_string($con,$login_user);
        $deptID = mysqli_real_escape_string($con,$deptID);
        $myquery = "SELECT S.SID, S.FullName, S.USN, S.Semester, S.Section, S.Email, S.Mobile, S.YearOfJoin, S.CourseReg, S.Profile_P, S.Profile_G, S.Profile_A, S.Profile_S FROM Student S ";
        $myquery .= " WHERE S.Proctor = $facultyID";
        $myquery .= " ORDER BY S.USN ASC";
        $result = mysqli_query($con, $myquery);
        $response['students'] = array();
        if($result) {
            if(mysqli_num_rows($result) > 0) {
                while($row = mysqli_fetch_assoc($result)) {
                    array_push($response["students"], $row);
                }
                mysqli_close($con);
                return $response['students'];
            }
        }
        mysqli_close($con);
        return NULL;
    }












    if(isset($_SESSION['facultyID']) && isset($_SESSION['deptID'])) {
        echo json_encode(getProctorStudentList($_SESSION['facultyID']);
    }
    else {
        $response["status"] = "";
        echo json_encode($response);
    }