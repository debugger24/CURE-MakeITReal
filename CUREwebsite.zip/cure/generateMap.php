<?php

// TODO @Tarun: Accept Data in POST format and dump in Database

// TODO @Tarun: Return status {"status" : "success"} or {"status" : "fail"} in JSON

print_r($_GET);

/*
 [
  {location: new google.maps.LatLng(37.782, -122.447), weight: 0.5},
  new google.maps.LatLng(37.782, -122.445),
  {location: new google.maps.LatLng(37.782, -122.443), weight: 2},
  {location: new google.maps.LatLng(37.782, -122.441), weight: 3},
  {location: new google.maps.LatLng(37.782, -122.439), weight: 2},
  new google.maps.LatLng(37.782, -122.437),
  {location: new google.maps.LatLng(37.782, -122.435), weight: 0.5},

  {location: new google.maps.LatLng(37.785, -122.447), weight: 3},
  {location: new google.maps.LatLng(37.785, -122.445), weight: 2},
  new google.maps.LatLng(37.785, -122.443),
  {location: new google.maps.LatLng(37.785, -122.441), weight: 0.5},
  new google.maps.LatLng(37.785, -122.439),
  {location: new google.maps.LatLng(37.785, -122.437), weight: 2},
  {location: new google.maps.LatLng(37.785, -122.435), weight: 3}
];
*/

//SELECT Disease, District, Lat, Lon, Count(*) FROM DATASHEET WHERE Disease = "Malaria" GROUP BY District


function generateMap($dis) {
	//

	//
	//return  array("status"=>"fail") ;


	include("config.php");
	$conn=$db;
	if ($conn->connect_error) {
		return array("status"=>"fail") ;
		die("Connection failed: " . $conn->connect_error);
	} 

	$strng="[";

	$sql = "SELECT Disease, District, Lat, Lon, Count(*) FROM DATASHEET WHERE Disease = '$dis' GROUP BY District";
	$result = $conn->query($sql);
	//echo $sql;
	$flag=0;

	if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
       
      if($flag==1){
      	$strng.=",";

      }
      $flag=1;
       	$Lt=$row['Lat'];$Ln=$row['Lon'];$Wt=$row['Count(*)'];

       	$strng.="{location: new google.maps.LatLng($Lt, $Ln), weight: $Wt}";

       	// DEVELOP STRING HERE....

    	}
    $strng.="];";

	}	 
	$conn->close();
	echo $strng;
	//return array("status"=>"success");

	// TODO @Tarun: Return status {"status" : "success"} or {"status" : "fail"} in JSON
}











echo json_encode( generateMap($_GET['Disease']));





?>
