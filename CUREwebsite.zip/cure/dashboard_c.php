<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png" />
	<link rel="icon" type="image/png" href="assets/img/favicon.png" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>CURE = Curing Urban and Rural Equally</title>
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
	<meta name="viewport" content="width=device-width" />
	<?php include "lib/css.php" ?>
</head>

<body>
	<div class="wrapper">
		<div class="sidebar" data-active-color="rose" data-background-color="white" data-image="assets/img/sidebar-1.jpg">
			<div class="logo">
				<a href="#" class="simple-text logo-mini">

                </a>
				<a href="#" class="simple-text logo-normal">
                    CURE
                </a>
			</div>
			<div class="sidebar-wrapper">
				<ul class="nav">
					<li class="active">
						<a href="dashboard.php">
                            <i class="material-icons">dashboard</i>
                            <p>Dashboard</p>
                        </a>
					</li>
					<li>
						<a href="patients_c.php">
                            <i class="material-icons">person</i>
                            <p>Patients</p>
                        </a>
					</li>
					<li>
						<a href="revenue.php">
                            <i class="fa fa-line-chart" aria-hidden="true"></i>
                            <p>Revenue</p>
                        </a>
					</li>
					<li>
						<a href="rating.php">
                            <i class="fa fa-star-half-o" aria-hidden="true"></i>
                            <p>Rating and Feedback</p>
                        </a>
					</li>
					<li>
						<a href="map.php">
                            <i class="material-icons">location_on</i>
                            <p>Disease Map</p>
                        </a>
					</li>
				</ul>
			</div>
		</div>
		<div class="main-panel">
			<nav class="navbar navbar-transparent navbar-absolute">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
						<a class="navbar-brand" href="#"> Empty </a>
					</div>
				</div>
			</nav>
			<div class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-4">
							<div class="card card-chart" data-count="1">
								<div class="card-header" data-background-color="rose" data-header-animation="true">
									<div class="ct-chart" id="websiteViewsChart"><svg xmlns:ct="http://gionkunz.github.com/chartist-js/ct" width="100%" height="100%" class="ct-chart-bar" style="width: 100%; height: 100%;"><g class="ct-grids"><line y1="120" y2="120" x1="40" x2="430" class="ct-grid ct-vertical"></line><line y1="96" y2="96" x1="40" x2="430" class="ct-grid ct-vertical"></line><line y1="72" y2="72" x1="40" x2="430" class="ct-grid ct-vertical"></line><line y1="48" y2="48" x1="40" x2="430" class="ct-grid ct-vertical"></line><line y1="24" y2="24" x1="40" x2="430" class="ct-grid ct-vertical"></line><line y1="0" y2="0" x1="40" x2="430" class="ct-grid ct-vertical"></line></g><g><g class="ct-series ct-series-a"><line x1="56.25" x2="56.25" y1="120" y2="54.959999999999994" class="ct-bar" value="542" opacity="1"></line><line x1="88.75" x2="88.75" y1="120" y2="66.84" class="ct-bar" value="443" opacity="1"></line><line x1="121.25" x2="121.25" y1="120" y2="81.6" class="ct-bar" value="320" opacity="1"></line><line x1="153.75" x2="153.75" y1="120" y2="26.400000000000006" class="ct-bar" value="780" opacity="1"></line><line x1="186.25" x2="186.25" y1="120" y2="53.64" class="ct-bar" value="553" opacity="1"></line><line x1="218.75" x2="218.75" y1="120" y2="65.64" class="ct-bar" value="453" opacity="1"></line><line x1="251.25" x2="251.25" y1="120" y2="80.88" class="ct-bar" value="326" opacity="1"></line><line x1="283.75" x2="283.75" y1="120" y2="67.92" class="ct-bar" value="434" opacity="1"></line><line x1="316.25" x2="316.25" y1="120" y2="51.84" class="ct-bar" value="568" opacity="1"></line><line x1="348.75" x2="348.75" y1="120" y2="46.8" class="ct-bar" value="610" opacity="1"></line><line x1="381.25" x2="381.25" y1="120" y2="29.28" class="ct-bar" value="756" opacity="1"></line><line x1="413.75" x2="413.75" y1="120" y2="12.599999999999994" class="ct-bar" value="895" opacity="1"></line></g></g><g class="ct-labels"><foreignObject style="overflow: visible;" x="40" y="125" width="32.5" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 33px; height: 20px;">J</span></foreignObject><foreignObject style="overflow: visible;" x="72.5" y="125" width="32.5" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 33px; height: 20px;">F</span></foreignObject><foreignObject style="overflow: visible;" x="105" y="125" width="32.5" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 33px; height: 20px;">M</span></foreignObject><foreignObject style="overflow: visible;" x="137.5" y="125" width="32.5" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 33px; height: 20px;">A</span></foreignObject><foreignObject style="overflow: visible;" x="170" y="125" width="32.5" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 33px; height: 20px;">M</span></foreignObject><foreignObject style="overflow: visible;" x="202.5" y="125" width="32.5" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 33px; height: 20px;">J</span></foreignObject><foreignObject style="overflow: visible;" x="235" y="125" width="32.5" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 33px; height: 20px;">J</span></foreignObject><foreignObject style="overflow: visible;" x="267.5" y="125" width="32.5" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 33px; height: 20px;">A</span></foreignObject><foreignObject style="overflow: visible;" x="300" y="125" width="32.5" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 33px; height: 20px;">S</span></foreignObject><foreignObject style="overflow: visible;" x="332.5" y="125" width="32.5" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 33px; height: 20px;">O</span></foreignObject><foreignObject style="overflow: visible;" x="365" y="125" width="32.5" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 33px; height: 20px;">N</span></foreignObject><foreignObject style="overflow: visible;" x="397.5" y="125" width="32.5" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 33px; height: 20px;">D</span></foreignObject><foreignObject style="overflow: visible;" y="96" x="0" height="24" width="30"><span class="ct-label ct-vertical ct-start" xmlns="http://www.w3.org/2000/xmlns/" style="height: 24px; width: 30px;">0</span></foreignObject><foreignObject style="overflow: visible;" y="72" x="0" height="24" width="30"><span class="ct-label ct-vertical ct-start" xmlns="http://www.w3.org/2000/xmlns/" style="height: 24px; width: 30px;">200</span></foreignObject><foreignObject style="overflow: visible;" y="48" x="0" height="24" width="30"><span class="ct-label ct-vertical ct-start" xmlns="http://www.w3.org/2000/xmlns/" style="height: 24px; width: 30px;">400</span></foreignObject><foreignObject style="overflow: visible;" y="24" x="0" height="24" width="30"><span class="ct-label ct-vertical ct-start" xmlns="http://www.w3.org/2000/xmlns/" style="height: 24px; width: 30px;">600</span></foreignObject><foreignObject style="overflow: visible;" y="0" x="0" height="24" width="30"><span class="ct-label ct-vertical ct-start" xmlns="http://www.w3.org/2000/xmlns/" style="height: 24px; width: 30px;">800</span></foreignObject><foreignObject style="overflow: visible;" y="-30" x="0" height="30" width="30"><span class="ct-label ct-vertical ct-start" xmlns="http://www.w3.org/2000/xmlns/" style="height: 30px; width: 30px;">1000</span></foreignObject></g></svg></div>
								</div>
								<div class="card-content">
									<div class="card-actions">
										<button type="button" class="btn btn-danger btn-simple fix-broken-card">
                                            <i class="material-icons">build</i> Fix Header!
                                        </button>
										<button type="button" class="btn btn-info btn-simple" rel="tooltip" data-placement="bottom" title="" data-original-title="Refresh">
                                            <i class="material-icons">refresh</i>
                                        </button>
										<button type="button" class="btn btn-default btn-simple" rel="tooltip" data-placement="bottom" title="" data-original-title="Change Date">
                                            <i class="material-icons">edit</i>
                                        </button>
									</div>
									<h4 class="card-title">Website Views</h4>
									<p class="category">Last Campaign Performance</p>
								</div>
								<div class="card-footer">
									<div class="stats">
										<i class="material-icons">access_time</i> campaign sent 2 days ago
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="card card-chart" data-count="4">
								<div class="card-header" data-background-color="green" data-header-animation="true">
									<div class="ct-chart" id="dailySalesChart"><svg xmlns:ct="http://gionkunz.github.com/chartist-js/ct" width="100%" height="100%" class="ct-chart-line" style="width: 100%; height: 100%;"><g class="ct-grids"><line x1="40" x2="40" y1="0" y2="120" class="ct-grid ct-horizontal"></line><line x1="96.42857142857143" x2="96.42857142857143" y1="0" y2="120" class="ct-grid ct-horizontal"></line><line x1="152.85714285714286" x2="152.85714285714286" y1="0" y2="120" class="ct-grid ct-horizontal"></line><line x1="209.28571428571428" x2="209.28571428571428" y1="0" y2="120" class="ct-grid ct-horizontal"></line><line x1="265.7142857142857" x2="265.7142857142857" y1="0" y2="120" class="ct-grid ct-horizontal"></line><line x1="322.14285714285717" x2="322.14285714285717" y1="0" y2="120" class="ct-grid ct-horizontal"></line><line x1="378.57142857142856" x2="378.57142857142856" y1="0" y2="120" class="ct-grid ct-horizontal"></line><line y1="120" y2="120" x1="40" x2="435" class="ct-grid ct-vertical"></line><line y1="96" y2="96" x1="40" x2="435" class="ct-grid ct-vertical"></line><line y1="72" y2="72" x1="40" x2="435" class="ct-grid ct-vertical"></line><line y1="48" y2="48" x1="40" x2="435" class="ct-grid ct-vertical"></line><line y1="24" y2="24" x1="40" x2="435" class="ct-grid ct-vertical"></line><line y1="0" y2="0" x1="40" x2="435" class="ct-grid ct-vertical"></line></g><g><g class="ct-series ct-series-a"><path d="M 40 91.2 C 96.429 79.2 96.429 79.2 96.429 79.2 C 152.857 103.2 152.857 103.2 152.857 103.2 C 209.286 79.2 209.286 79.2 209.286 79.2 C 265.714 64.8 265.714 64.8 265.714 64.8 C 322.143 76.8 322.143 76.8 322.143 76.8 C 378.571 28.8 378.571 28.8 378.571 28.8" class="ct-line"></path><line x1="40" y1="91.2" x2="40.01" y2="91.2" class="ct-point" value="12" opacity="1"></line><line x1="96.42857142857143" y1="79.2" x2="96.43857142857144" y2="79.2" class="ct-point" value="17" opacity="1"></line><line x1="152.85714285714286" y1="103.2" x2="152.86714285714285" y2="103.2" class="ct-point" value="7" opacity="1"></line><line x1="209.28571428571428" y1="79.2" x2="209.29571428571427" y2="79.2" class="ct-point" value="17" opacity="1"></line><line x1="265.7142857142857" y1="64.8" x2="265.7242857142857" y2="64.8" class="ct-point" value="23" opacity="1"></line><line x1="322.14285714285717" y1="76.8" x2="322.15285714285716" y2="76.8" class="ct-point" value="18" opacity="1"></line><line x1="378.57142857142856" y1="28.799999999999997" x2="378.58142857142855" y2="28.799999999999997" class="ct-point" value="38" opacity="1"></line></g></g><g class="ct-labels"><foreignObject style="overflow: visible;" x="40" y="125" width="56.42857142857143" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 56px; height: 20px;">M</span></foreignObject><foreignObject style="overflow: visible;" x="96.42857142857143" y="125" width="56.42857142857143" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 56px; height: 20px;">T</span></foreignObject><foreignObject style="overflow: visible;" x="152.85714285714286" y="125" width="56.428571428571416" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 56px; height: 20px;">W</span></foreignObject><foreignObject style="overflow: visible;" x="209.28571428571428" y="125" width="56.428571428571445" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 56px; height: 20px;">T</span></foreignObject><foreignObject style="overflow: visible;" x="265.7142857142857" y="125" width="56.428571428571445" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 56px; height: 20px;">F</span></foreignObject><foreignObject style="overflow: visible;" x="322.14285714285717" y="125" width="56.42857142857139" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 56px; height: 20px;">S</span></foreignObject><foreignObject style="overflow: visible;" x="378.57142857142856" y="125" width="56.428571428571445" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 56px; height: 20px;">S</span></foreignObject><foreignObject style="overflow: visible;" y="96" x="0" height="24" width="30"><span class="ct-label ct-vertical ct-start" xmlns="http://www.w3.org/2000/xmlns/" style="height: 24px; width: 30px;">0</span></foreignObject><foreignObject style="overflow: visible;" y="72" x="0" height="24" width="30"><span class="ct-label ct-vertical ct-start" xmlns="http://www.w3.org/2000/xmlns/" style="height: 24px; width: 30px;">10</span></foreignObject><foreignObject style="overflow: visible;" y="48" x="0" height="24" width="30"><span class="ct-label ct-vertical ct-start" xmlns="http://www.w3.org/2000/xmlns/" style="height: 24px; width: 30px;">20</span></foreignObject><foreignObject style="overflow: visible;" y="24" x="0" height="24" width="30"><span class="ct-label ct-vertical ct-start" xmlns="http://www.w3.org/2000/xmlns/" style="height: 24px; width: 30px;">30</span></foreignObject><foreignObject style="overflow: visible;" y="0" x="0" height="24" width="30"><span class="ct-label ct-vertical ct-start" xmlns="http://www.w3.org/2000/xmlns/" style="height: 24px; width: 30px;">40</span></foreignObject><foreignObject style="overflow: visible;" y="-30" x="0" height="30" width="30"><span class="ct-label ct-vertical ct-start" xmlns="http://www.w3.org/2000/xmlns/" style="height: 30px; width: 30px;">50</span></foreignObject></g></svg></div>
								</div>
								<div class="card-content">
									<div class="card-actions">
										<button type="button" class="btn btn-danger btn-simple fix-broken-card">
                                            <i class="material-icons">build</i> Fix Header!
                                        </button>
										<button type="button" class="btn btn-info btn-simple" rel="tooltip" data-placement="bottom" title="" data-original-title="Refresh">
                                            <i class="material-icons">refresh</i>
                                        <div class="ripple-container"></div></button>
										<button type="button" class="btn btn-default btn-simple" rel="tooltip" data-placement="bottom" title="" data-original-title="Change Date">
                                            <i class="material-icons">edit</i>
                                        </button>
									</div>
									<h4 class="card-title">Daily Patient Visits</h4>
									<p class="category">
										<span class="text-success"><i class="fa fa-long-arrow-up"></i> 55% </span> increase in today sales.</p>
								</div>
								<div class="card-footer">
									<div class="stats">
										<i class="material-icons">access_time</i> updated 4 minutes ago
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="card card-chart" data-count="2">
								<div class="card-header" data-background-color="blue" data-header-animation="true">
									<div class="ct-chart" id="completedTasksChart"><svg xmlns:ct="http://gionkunz.github.com/chartist-js/ct" width="100%" height="100%" class="ct-chart-line" style="width: 100%; height: 100%;"><g class="ct-grids"><line x1="40" x2="40" y1="0" y2="120" class="ct-grid ct-horizontal"></line><line x1="89.375" x2="89.375" y1="0" y2="120" class="ct-grid ct-horizontal"></line><line x1="138.75" x2="138.75" y1="0" y2="120" class="ct-grid ct-horizontal"></line><line x1="188.125" x2="188.125" y1="0" y2="120" class="ct-grid ct-horizontal"></line><line x1="237.5" x2="237.5" y1="0" y2="120" class="ct-grid ct-horizontal"></line><line x1="286.875" x2="286.875" y1="0" y2="120" class="ct-grid ct-horizontal"></line><line x1="336.25" x2="336.25" y1="0" y2="120" class="ct-grid ct-horizontal"></line><line x1="385.625" x2="385.625" y1="0" y2="120" class="ct-grid ct-horizontal"></line><line y1="120" y2="120" x1="40" x2="435" class="ct-grid ct-vertical"></line><line y1="96" y2="96" x1="40" x2="435" class="ct-grid ct-vertical"></line><line y1="72" y2="72" x1="40" x2="435" class="ct-grid ct-vertical"></line><line y1="48" y2="48" x1="40" x2="435" class="ct-grid ct-vertical"></line><line y1="24" y2="24" x1="40" x2="435" class="ct-grid ct-vertical"></line><line y1="0" y2="0" x1="40" x2="435" class="ct-grid ct-vertical"></line></g><g><g class="ct-series ct-series-a"><path d="M 40 92.4 C 89.375 30 89.375 30 89.375 30 C 138.75 66 138.75 66 138.75 66 C 188.125 84 188.125 84 188.125 84 C 237.5 86.4 237.5 86.4 237.5 86.4 C 286.875 91.2 286.875 91.2 286.875 91.2 C 336.25 96 336.25 96 336.25 96 C 385.625 97.2 385.625 97.2 385.625 97.2" class="ct-line"></path><line x1="40" y1="92.4" x2="40.01" y2="92.4" class="ct-point" value="230" opacity="1"></line><line x1="89.375" y1="30" x2="89.385" y2="30" class="ct-point" value="750" opacity="1"></line><line x1="138.75" y1="66" x2="138.76" y2="66" class="ct-point" value="450" opacity="1"></line><line x1="188.125" y1="84" x2="188.135" y2="84" class="ct-point" value="300" opacity="1"></line><line x1="237.5" y1="86.4" x2="237.51" y2="86.4" class="ct-point" value="280" opacity="1"></line><line x1="286.875" y1="91.2" x2="286.885" y2="91.2" class="ct-point" value="240" opacity="1"></line><line x1="336.25" y1="96" x2="336.26" y2="96" class="ct-point" value="200" opacity="1"></line><line x1="385.625" y1="97.2" x2="385.635" y2="97.2" class="ct-point" value="190" opacity="1"></line></g></g><g class="ct-labels"><foreignObject style="overflow: visible;" x="40" y="125" width="49.375" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 49px; height: 20px;">12p</span></foreignObject><foreignObject style="overflow: visible;" x="89.375" y="125" width="49.375" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 49px; height: 20px;">3p</span></foreignObject><foreignObject style="overflow: visible;" x="138.75" y="125" width="49.375" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 49px; height: 20px;">6p</span></foreignObject><foreignObject style="overflow: visible;" x="188.125" y="125" width="49.375" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 49px; height: 20px;">9p</span></foreignObject><foreignObject style="overflow: visible;" x="237.5" y="125" width="49.375" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 49px; height: 20px;">12p</span></foreignObject><foreignObject style="overflow: visible;" x="286.875" y="125" width="49.375" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 49px; height: 20px;">3a</span></foreignObject><foreignObject style="overflow: visible;" x="336.25" y="125" width="49.375" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 49px; height: 20px;">6a</span></foreignObject><foreignObject style="overflow: visible;" x="385.625" y="125" width="49.375" height="20"><span class="ct-label ct-horizontal ct-end" xmlns="http://www.w3.org/2000/xmlns/" style="width: 49px; height: 20px;">9a</span></foreignObject><foreignObject style="overflow: visible;" y="96" x="0" height="24" width="30"><span class="ct-label ct-vertical ct-start" xmlns="http://www.w3.org/2000/xmlns/" style="height: 24px; width: 30px;">0</span></foreignObject><foreignObject style="overflow: visible;" y="72" x="0" height="24" width="30"><span class="ct-label ct-vertical ct-start" xmlns="http://www.w3.org/2000/xmlns/" style="height: 24px; width: 30px;">200</span></foreignObject><foreignObject style="overflow: visible;" y="48" x="0" height="24" width="30"><span class="ct-label ct-vertical ct-start" xmlns="http://www.w3.org/2000/xmlns/" style="height: 24px; width: 30px;">400</span></foreignObject><foreignObject style="overflow: visible;" y="24" x="0" height="24" width="30"><span class="ct-label ct-vertical ct-start" xmlns="http://www.w3.org/2000/xmlns/" style="height: 24px; width: 30px;">600</span></foreignObject><foreignObject style="overflow: visible;" y="0" x="0" height="24" width="30"><span class="ct-label ct-vertical ct-start" xmlns="http://www.w3.org/2000/xmlns/" style="height: 24px; width: 30px;">800</span></foreignObject><foreignObject style="overflow: visible;" y="-30" x="0" height="30" width="30"><span class="ct-label ct-vertical ct-start" xmlns="http://www.w3.org/2000/xmlns/" style="height: 30px; width: 30px;">1000</span></foreignObject></g></svg></div>
								</div>
								<div class="card-content">
									<div class="card-actions">
										<button type="button" class="btn btn-danger btn-simple fix-broken-card">
                                            <i class="material-icons">build</i> Fix Header!
                                        </button>
										<button type="button" class="btn btn-info btn-simple" rel="tooltip" data-placement="bottom" title="" data-original-title="Refresh">
                                            <i class="material-icons">refresh</i>
                                        </button>
										<button type="button" class="btn btn-default btn-simple" rel="tooltip" data-placement="bottom" title="" data-original-title="Change Date">
                                            <i class="material-icons">edit</i>
                                        </button>
									</div>
									<h4 class="card-title">Completed Tasks</h4>
									<p class="category">Last Campaign Performance</p>
								</div>
								<div class="card-footer">
									<div class="stats">
										<i class="material-icons">access_time</i> campaign sent 2 days ago
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<footer class="footer">
				<div class="container-fluid">
					<p class="copyright pull-right">
						&copy;
						<script>
							document.write(new Date().getFullYear())
						</script>
						Developed by TeamName (a.k.a HumBeerHein)</a>
					</p>
				</div>
			</footer>
		</div>
	</div>
</body>
<?php include "lib/js.php" ?>

</html>
