<?php

// TODO @Tarun: Change Doctor Status to Offline

	session_start();
	include("config.php");
	$conn=$db;
	if ($conn->connect_error) {
		return array("status"=>"fail") ;
		die("Connection failed: " . $conn->connect_error);
	} 

	$sql="UPDATE Doctor SET Status='Offline' Where email=$_SESSION['login_user']";
	
	$result = $conn->query($sql);

unset();
session_destroy();

	$conn->close();
// TODO @Tarun: Redirect to Doctor Login

      header("location: login.php");

?>
