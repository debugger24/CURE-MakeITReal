<?php

// TODO @Tarun: Accept Data in POST format and dump in Database

// TODO @Tarun: Return status {"status" : "success"} or {"status" : "fail"} in JSON

print_r($_POST);

?>
