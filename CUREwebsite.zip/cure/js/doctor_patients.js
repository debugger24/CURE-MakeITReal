function getAppoinments() {
    $.ajax('doctor/getAppoinments.json', {
        success: function(result) {
            console.log(result);
            var appoinmentList = $.map(result, function(appoinment, i) {
                var appoinmentRow = $('<tr></tr>');
                $('<td class="text-center">1</td>').appendTo(appoinmentRow);
                $('<td>' + appoinment.patient_name + '</td>').appendTo(appoinmentRow);
                $('<td>' + appoinment.locality + '</td>').appendTo(appoinmentRow);
                $('<td>' + appoinment.age + '</td>').appendTo(appoinmentRow);
                $('<td>' + appoinment.sex + '</td>').appendTo(appoinmentRow);
                $('<td>' + appoinment.symptoms + '</td>').appendTo(appoinmentRow);
                $('<td class="text-right">' + appoinment.appoinment_time + '</td>').appendTo(appoinmentRow);

                var controlAppoinment = $('<td class="td-actions text-right"></td>');
                // $('<a href="patients.php?appoinment_id=' +  + '" <button type="button" rel="tooltip" class="btn btn-info" data-original-title="" title="Patient Details"><i class="fa fa-user" aria-hidden="true"></i></button>').appendTo(controlAppoinment);
                $('<a href="patients.php?appoinment_id=' + appoinment.appoinment_id + '" <button type="button" rel="tooltip" class="btn btn-danger" data-original-title="" title="Call"><i class="fa fa-video-camera" aria-hidden="true"></i></button>').appendTo(controlAppoinment);

                controlAppoinment.appendTo(appoinmentRow);
                return appoinmentRow;
            });
            $('#appoinmentList').html(appoinmentList);
            $('i').tooltip();
        },
        error: function() {
            // Materialize.toast("Failed: Please contact admin.", 4000);
        },
        timeout: 5000,
        beforeSend: function() {
            // preloader.addClass('active');
            // preloader.css('display','block');
        },
        complete: function() {
            // preloader.removeClass('active');
            // preloader.css('display','none');
        }
    });
}

function generateReport(event) {
    var form = $("form");
    var formData = new FormData(document.getElementById("generateReportForm"));
    event.preventDefault();
    $.ajax(form.attr('action'), {
        type: 'POST',
        data: formData,
        contentType: false,
        cache: false,
        processData:false,
        dataType: "json",
        success: function(result) {
            if(result.result == "success") {
                // SUCCESS
            }
            else if (result.result == "failed") {
                // FAILED
            }
            else {
                // FAILED
            }
        },
        error: function(result) {
            // FAILED
        },
        timeout: 5000
    });
}

$(document).ready(function(){
    getAppoinments();
    $("#generateReportForm").on('submit', generateReport);
});
