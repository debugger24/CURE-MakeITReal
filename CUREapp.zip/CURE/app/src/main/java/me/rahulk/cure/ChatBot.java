package me.rahulk.cure;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link ChatBot.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link ChatBot#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ChatBot extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    ImageView imgSend;
    EditText editMessage;
    View viewInlineText, viewInlineBoolean;
    LinearLayout viewChatWindow;
    Button btnYes, btnNo;

    public ChatBot() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment ChatBot.
     */
    // TODO: Rename and change types and number of parameters
    public static ChatBot newInstance(String param1, String param2) {
        ChatBot fragment = new ChatBot();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_chat_bot, container, false);

        imgSend = (ImageView) rootView.findViewById(R.id.imgSend);
        editMessage = (EditText) rootView.findViewById(R.id.editMessage);
        btnYes = (Button) rootView.findViewById(R.id.btnYes);
        btnNo = (Button) rootView.findViewById(R.id.btnNo);

        viewInlineText = rootView.findViewById(R.id.viewInlineText);
        viewInlineBoolean = rootView.findViewById(R.id.viewInlineBoolean);
        viewChatWindow = rootView.findViewById(R.id.viewChatWindow);

        imgSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addSendingMessage(editMessage.getText().toString());
                sendMessage(editMessage.getText().toString());
            }
        });

        btnYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addSendingMessage("Yes");
                sendMessage("Yes");
            }
        });

        btnNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addSendingMessage("No");
                sendMessage("No");
            }
        });

        return rootView;
    }

    private void addSendingMessage(String message) {
        View viewEvent = LayoutInflater.from(getContext()).inflate(R.layout.chat_out, null);
        TextView chat_text = (TextView) viewEvent.findViewById(R.id.chat_text);
        chat_text.setText(message);
        viewChatWindow.addView(viewEvent);
    }


    private void sendMessage(final String message) {
        StringRequest strReq = new StringRequest(Request.Method.POST, "http://139.59.68.68:5000", new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                if (getContext() != null) {
                    try {
                        Log.v("SUB JSON RESPONSE", response);
                        JSONObject jsonObject = new JSONObject(response);

                        // Get Message
                        String message = jsonObject.getString("message");

                        // Put Incoming Message in Bubble
                        View viewEvent = LayoutInflater.from(getContext()).inflate(R.layout.chat_in, null);
                        TextView chat_text = (TextView) viewEvent.findViewById(R.id.chat_text);
                        chat_text.setText(message);
                        viewChatWindow.addView(viewEvent);


                        // Check Flag
                        int flag = jsonObject.getInt("flag");
                        if (flag == 0) {
                            viewInlineText.setVisibility(View.VISIBLE);
                            viewInlineBoolean.setVisibility(View.GONE);
                        }
                        if (flag == 1) {
                            viewInlineText.setVisibility(View.GONE);
                            viewInlineBoolean.setVisibility(View.VISIBLE);
                        }
                        if (flag == 2) {
                            viewInlineText.setVisibility(View.GONE);
                            viewInlineBoolean.setVisibility(View.GONE);
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(getContext(), "Something went wrong. Try Again", Toast.LENGTH_LONG).show();
                    } finally {
//                        swipeContainer.setRefreshing(false);
                    }
                }
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError volleyError) {
                if (getContext() != null) {
                    Toast.makeText(getContext(), "FAILED TO SUBMIT. Try Again", Toast.LENGTH_LONG).show();
                }
//                swipeContainer.setRefreshing(false);
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                // Posting params to register url
                Map<String, String> params = new HashMap<String, String>();

                // Personal Info
                params.put("message", message);
                params.put("user_id", "rahulcomp24@gmail.com");

                return params;
            }
        };

        AppController.getInstance().addToRequestQueue(strReq, "Submit Answers");
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
